# 📊 Sentiment Analysis on IMDb Reviews

## 📌 Project Overview
This project focuses on **sentiment analysis** using the IMDb Reviews dataset. The aim is to classify movie reviews as **positive** or **negative** based on their textual content.

---

## 🗂️ Project Structure
```
📦 Sentiment Analysis Project
│── imdb_reviews.csv            # Dataset file (CSV format)
│── sentiment_analysis.py       # Main Python script
│── README.md                   # Project documentation
│── requirements.txt            # Required Python libraries
```

---

## 🔧 Requirements
To run this project, you need:
- Python 3.x
- Libraries:
  - pandas
  - numpy
  - sklearn
  - nltk
  - gensim (if using Word2Vec)

Install all dependencies using:

pip install -r requirements.txt

---

## 📂 Dataset Information
- **Source:** IMDb Reviews (CSV file)
- **Columns:**
  - `review`: Text of the movie review
  - `sentiment`: Sentiment label (positive/negative)

---

## 🚀 Steps to Run the Project


Sentiment Analysis Project
shift+Enter for (jupyter notebook cell)
sentiment_analysis.ipynb


---

## 🧠 Project Workflow
### Step 1: Text Preprocessing
- Tokenization
- Stopwords removal
- Lemmatization using **NLTK**

### Step 2: Feature Engineering
- **TF-IDF Vectorization** to convert text into numerical data.
- Optionally, **Word2Vec** for word embeddings.

### Step 3: Model Training
- Trained **Logistic Regression** and **Naive Bayes** classifiers.
- Evaluated using:
  - **Accuracy Score**
  - **Classification Report**

## 📊 Results & Evaluation
| Model                 | Accuracy |
|-----------------------|----------|
| Logistic Regression   | ~88%     |
| Naive Bayes           | ~83%     |



## 📩 Contact
For any questions or collaboration, reach out to:
**Muhammad Ali Zaib** - becauseofwork47@gmail.com
